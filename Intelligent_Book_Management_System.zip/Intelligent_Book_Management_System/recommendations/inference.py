import joblib
import pandas as pd
class BookRecommender:
    def __init__(self, model_path: str, encoder_path: str, y_train_path: str):
        """
        Initializes the BookRecommender with a KNN model, label encoder, and training data.

        :param model_path: Path to the trained KNN model.
        :param encoder_path: Path to the label encoder.
        :param y_train_path: Path to the training data containing book titles.
        """
        self.knn = joblib.load(model_path)
        self.label_encoder = joblib.load(encoder_path)
        self.y_train = joblib.load(y_train_path)

    def recommend_books(self, genre: str, avg_rating: float) -> list:
        """
        Recommends books based on genre and average rating using KNN.

        :param genre: The genre of books to recommend.
        :param avg_rating: The average rating of the books.
        :return: A list of recommended book titles.
        """
        if genre not in self.label_encoder.classes_:
            return ["Genre not found in the dataset."]

        # Encode the genre
        genre_encoded = self.label_encoder.transform([genre])[0]

        # Create a DataFrame for the input
        input_df = pd.DataFrame([[genre_encoded, avg_rating]], columns=['genres_encoded', 'average_rating'])

        # Get the distances and indices of the nearest neighbors
        distances, indices = self.knn.kneighbors(input_df, n_neighbors=5)

        # Get the recommended titles and ensure unique recommendations
        recommended_titles = self.y_train.iloc[indices[0]].values
        unique_titles = list(dict.fromkeys(recommended_titles))  

        return unique_titles




