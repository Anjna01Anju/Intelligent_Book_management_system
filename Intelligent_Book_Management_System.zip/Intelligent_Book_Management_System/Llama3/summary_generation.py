import json
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline, BitsAndBytesConfig
from langchain_huggingface import HuggingFacePipeline
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain

class TextSummarizer:
    """
    A class to generate summaries of text using a pre-trained language model.

    Attributes:
        token (str): Authentication token for accessing the model.
        model_path (str): Path to the pre-trained language model.
        tokenizer (AutoTokenizer): Tokenizer for the model.
        bnb_config (BitsAndBytesConfig): Configuration for quantization of the model.
        model (AutoModelForCausalLM): Pre-trained language model for text generation.
        text_generator (pipeline): Pipeline for text generation.
        local_llm (HuggingFacePipeline): Local language model using HuggingFacePipeline.
    """
    
    def __init__(self, token: str, model_path: str):
        """
        Initializes the TextSummarizer with a token and model path.

        Args:
            token (str): Authentication token for accessing the model.
            model_path (str): Path to the pre-trained language model.
        """
        # Load token from JSON file
        self.token = token
        
        # Define model path
        self.model_path = model_path
        
        # Initialize tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, token=self.token)
        
        # Configure model quantization
        self.bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type='nf4',
            bnb_4_bit_compute_dtype=torch.bfloat16
        )
        
        # Initialize model
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_path,
            device_map="auto",
            token=self.token,
            quantization_config=self.bnb_config
        )
        
        # Initialize text generation pipeline
        self.text_generator = pipeline(
            "text-generation",
            model=self.model,
            tokenizer=self.tokenizer,
            torch_dtype=torch.bfloat16,
            max_length=3000,
            do_sample=True,
            top_k=10,
            num_return_sequences=1,
            eos_token_id=self.tokenizer.eos_token_id,
            device_map="auto"
        )
        
        # Initialize local language model
        self.local_llm = HuggingFacePipeline(pipeline=self.text_generator, model_kwargs={'template': 0})

    def generate_summary(self, content: str) -> str:
        """
        Generates a summary of the given content.

        Args:
            content (str): The text content to summarize.

        Returns:
            str: The generated summary including the book content with "SUMMARY:".
        """
        template = """
        Write a concise summary of the text, return your responses with 5 lines that cover the key points of the text.
        ```{text}```
        SUMMARY:
        """
        prompt = PromptTemplate(template=template, input_variables=["text"])
        llm_chain = LLMChain(prompt=prompt, llm=self.local_llm)
        summary = llm_chain.run(content)
        return summary

    def extract_summary(self, content: str) -> str:
        """
        Extracts the actual summary from the generated summary text.

        Args:
            content (str): The text content to summarize.

        Returns:
            str: The extracted summary text, or a message indicating that the summary was not found.
        """
        response_text = self.generate_summary(content)
        start_index = response_text.find("SUMMARY:") + len("SUMMARY:")
        if start_index != -1:
            return response_text[start_index:].strip()
        return "Summary not found."
